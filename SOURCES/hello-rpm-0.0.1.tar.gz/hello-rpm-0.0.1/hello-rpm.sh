#!/bin/sh

echo "hello rpm dev"